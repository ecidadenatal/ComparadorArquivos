<?php
/*
 *     E-cidade Software Publico para Gestao Municipal                
 *  Copyright (C) 2013  DBselller Servicos de Informatica             
 *                            www.dbseller.com.br                     
 *                         e-cidade@dbseller.com.br                   
 *                                                                    
 *  Este programa e software livre; voce pode redistribui-lo e/ou     
 *  modifica-lo sob os termos da Licenca Publica Geral GNU, conforme  
 *  publicada pela Free Software Foundation; tanto a versao 2 da      
 *  Licenca como (a seu criterio) qualquer versao mais nova.          
 *                                                                    
 *  Este programa e distribuido na expectativa de ser util, mas SEM   
 *  QUALQUER GARANTIA; sem mesmo a garantia implicita de              
 *  COMERCIALIZACAO ou de ADEQUACAO A QUALQUER PROPOSITO EM           
 *  PARTICULAR. Consulte a Licenca Publica Geral GNU para obter mais  
 *  detalhes.                                                         
 *                                                                    
 *  Voce deve ter recebido uma copia da Licenca Publica Geral GNU     
 *  junto com este programa; se nao, escreva para a Free Software     
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA          
 *  02111-1307, USA.                                                  
 *  
 *  Copia da licenca no diretorio licenca/licenca_en.txt 
 *                                licenca/licenca_pt.txt 
 */

function escreveXML($sPath, $iRow, $sConteudo) {
  	//SE O ARQUIVO AINDA N�O EXISTIR
  	if (!file_exists('files.xml')) {
  	//ESCREVE CABE�ALHO
        $oXmlWriter = new XMLWriter();
        $oXmlWriter->openMemory();
        $oXmlWriter->setIndent(true);
        $oXmlWriter->startDocument('1.0', 'ISO-8859-1');//'UTF-8');
        $oXmlWriter->endDtd();
        $oXmlWriter->startElement("modifications");
              //ESCREVE O ARQUIVO
              $oXmlWriter->startElement("file");
              $oXmlWriter->writeAttribute("path", $sPath);
                    //ESCREVE A MODIFICA��O
                    $oXmlWriter->startElement("modification");
                    //ESCREVE A LINHA
                    $oXmlWriter->startElement("row");
                    $oXmlWriter->writeCData($iRow);
                    $oXmlWriter->endElement();
                    //ESCREVE O CONTEUDO
                    $oXmlWriter->startElement("content");
                    $oXmlWriter->writeCData($sConteudo);
                    $oXmlWriter->endElement();
                    //FECHA A MODIFICACAO
                    $oXmlWriter->endElement();
              //FECHA O ARQUIVO
              $oXmlWriter->endElement();
        $oXmlWriter->endElement();
        $strBuffer  = $oXmlWriter->outputMemory();
        $rsXMl      = fopen('files.xml', 'w');
        fputs($rsXMl, utf8_decode($strBuffer));
        fclose($rsXMl); 
  	} else {
        $oDomXml  = new DOMDocument();
        $oDomXml->preserveWhiteSpace = false; 
        $oDomXml->formatOutput       = true;
        $oDomXml->load('files.xml');
        $oNoModifications   = $oDomXml->getElementsByTagName("modifications");
        $aModifications     = $oDomXml->getElementsByTagName("file");
        //Se j� existir modification no arquivo, s� acrescenta
        $lPathExist = false;
        foreach ($aModifications as $oModification) {
          
              	$lNodeExist   = false;
              	$sPathXML     = $oModification->getAttribute("path");
              	if ($sPathXML == $sPath) {
                    $lPathExist = true;
                    foreach ($oModification->childNodes as $oDadosModification) {
                          foreach ($oDadosModification->childNodes as $modification) {
                                if ($modification->nodeName == "row" && $modification->nodeValue == $iRow) {
                                  //NESSE MOMENTO SER� MESMO PATH E MESMA LINHA, PORTANTO, J� EXISTE
                                  	$lNodeExist = true;
                                  	echo "J� existe uma modifica��o na linha $iRow do arquivo $sPath. \n";
                                }       
                          }
                    }   
                    if ($lNodeExist == false) {
                        $oNewModification = $oDomXml->createElement("modification");
                
                        $oRow = $oDomXml->createElement("row");
                        $oRow->appendChild($oDomXml->createCDATASection(utf8_encode($iRow)));
                        $oNewModification->appendChild($oRow);
                          
                        $oContent = $oDomXml->createElement("content");
                        $oContent->appendChild($oDomXml->createCDATASection(utf8_encode($sConteudo)));
                        $oNewModification->appendChild($oContent);
                        $oModification->appendChild($oNewModification);
                          
                        $oDomXml->save('files.xml');
                    }
              	}
        }
        if ($lPathExist == false) {
              $oNewFile = $oDomXml->createElement("file");
              $oFileAttribute = $oDomXml->createAttribute("path");
              $oFileAttribute->value = $sPath;
              $oNewFile->appendChild($oFileAttribute);
              $oNewModification = $oDomXml->createElement("modification");
              
              $oRow = $oDomXml->createElement("row");
              $oRow->appendChild($oDomXml->createCDATASection($iRow));
              $oNewModification->appendChild($oRow);
              
              $oContent = $oDomXml->createElement("content");
              $oContent->appendChild($oDomXml->createCDATASection($sConteudo));
              $oNewModification->appendChild($oContent);
              
              $oNewFile->appendChild($oNewModification);
              
              $oNoModifications->item(0)->appendChild($oNewFile);
              $oDomXml->save(utf8_decode('files.xml'));                  
        }
  	}
}

function comparaArquivos() {
      $oDomXml  = new DOMDocument();
      $oDomXml->preserveWhiteSpace = false; 
      $oDomXml->formatOutput       = true;
      $oDomXml->load(utf8_encode('files.xml'));
      $oNoModifications   = $oDomXml->getElementsByTagName("modifications");
      $aModifications     = $oDomXml->getElementsByTagName("file");

      foreach ($aModifications as $oModification) {
            
            $sFilePath = $oModification->getAttribute("path");
            if (file_exists($sFilePath)) {
                  
                  foreach($oModification->childNodes as $oDadosModification) {
                        
                        foreach ($oDadosModification->childNodes as $modification) {
                              
                              if ($modification->nodeName == "row") {
                                    //Como o primeiro elemento de uma array � o 0, a linha inicial ser� sempre 1 anterior � cadastrada
                                    $iRow = $modification->nodeValue-1;
                              }
                              $aFile = file($sFilePath);
                              if ($modification->nodeName == "content") {
                                    $aContent = explode("\n", $modification->nodeValue);
                                    for ($i=0; $i < sizeof($aContent); $i++) { 
                                          if (strcmp(trim($aContent[$i]), trim($aFile[$iRow])) != 0) {
						                                    $iRowAtual = $iRow+1;
                                                echo "Diferen�a na linha ".$iRowAtual." do arquivo ".$sFilePath.".\n";
                                          }
                                          $iRow++;
                                    }
                              }
                        }
                  }
            }
      }
}

//TESTES

escreveXML("forms/db_frmliquidasemordem.php", 150, "              <tr>
                <td>
                  <label class=\"bold\" for=\"e03_numeroprocesso\">Processo Administrativo:</label>
                </td>
                <td colspan=\"3\">
                  <?php db_input('e03_numeroprocesso', 13, '', true, 'text', $db_opcao, null, null, null, null, 15); ?>
                </td>
              </tr>
              <!--[PLUGIN] CONTRATO PADRS -->

              <!--[Extensao OrdenadorDespesa] inclusao_ordenador-->

            </table>");
escreveXML("forms/db_frmliquidasemordem.php", 164, "            <fieldset class=\"separator\">
              <legend>Nota</legend>

              <table width=\"60%\">
                <!--[Extensao ContratosPADRS] serie nota -->
                <tr>
                  <td nowrap>
                    <label class=\"bold\" for=\"e69_numnota\">N�mero da Nota:</label>
                  </td>");
//escreveXML("", -, "");
//escreveXML("", -, "");
//escreveXML("", -, "");
//escreveXML("", -, "");
comparaArquivos();
?>
